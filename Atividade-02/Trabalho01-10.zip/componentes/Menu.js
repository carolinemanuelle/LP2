function Menu() {

    return (

        <nav>

            <ul>

                <a href="/">Home</a>&nbsp;

                <a href="/modelos">Modelos</a>

                <a href="/clientes">Clientes</a> 

                <a href="/contratos">Contratos</a> 

                <a href="/eventos">Eventos</a>

            </ul>

        </nav>

    );

}



export default Menu;