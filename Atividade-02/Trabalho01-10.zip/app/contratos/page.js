import { Contratos } from "../../database/tables";



async function TelaContratos() {

    const contratos = await Contratos.findAll();

    return (

        <div>

            <h1>Contratos</h1>
            <a href="/contratos/novo"> + um contrato </a> <br/>
            <table border="1">



                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Data de Início</th>

                        <th>Data de Fim</th>

                        <th>Valor</th>

                        <th>Numero do Contrato</th>



                    </tr>

                </thead>



                <tbody>

                    {

                        contratos.map(function(con) {

                            return (

                                <tr key={con.id}>

                                    <td>{con.id}</td>

                                    <td>{con.datini}</td>

                                    <td>{con.datfim}</td>

                                    <td>{con.valor}</td>

                                    <td>{con.numcon}</td>


                                </tr>

                            )

                        })

                    }

                </tbody>



            </table>



        </div>

    );

}



export default TelaContratos;