import { Modelos } from "../../database/tables";



async function TelaModelos() {

    const modelos = await Modelos.findAll();

    return (

        <div>

            <h1>Modelos</h1>
            <a href="/modelos/novo"> + uma modelo </a> <br/>
            <table border="1">



                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Nome</th>

                        <th>País</th>

                        <th>Altura</th>

                        <th>Massa</th>



                    </tr>

                </thead>



                <tbody>

                    {

                        modelos.map(function (mod) {

                            return (

                                <tr key={mod.id}>

                                    <td>{mod.id}</td>

                                    <td>{mod.nome}</td>

                                    <td>{mod.pais}</td>

                                    <td>{mod.altura}</td>

                                    <td>{mod.massa}</td>


                                </tr>

                            )

                        })

                    }

                </tbody>



            </table>



        </div>

    );

}



export default TelaModelos;