import { Clientes } from "../../database/tables";



async function TelaClientes() {

    const clientes = await Clientes.findAll();

    return (

        <div>

            <h1>Clientes</h1>
            <a href="/clientes/novo"> + uma cliente </a> <br/>
            <table border="1">



                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Nome</th>

                        <th>cnpj</th>

                        <th>Email</th>

                        <th>Telefone</th>



                    </tr>

                </thead>



                <tbody>

                    {

                        clientes.map(function (cli) {

                            return (

                                <tr key={cli.id}>

                                    <td>{cli.id}</td>

                                    <td>{cli.nome}</td>

                                    <td>{cli.cnpj}</td>

                                    <td>{cli.email}</td>

                                    <td>{cli.telefone}</td>


                                </tr>

                            )

                        })

                    }

                </tbody>



            </table>



        </div>

    );

}



export default TelaClientes;