import { Eventos } from "../../database/tables";



async function TelaEventos() {

    const eventos = await Eventos.findAll();

    return (

        <div>

            <h1>Eventos</h1>
            <a href="/eventos/novo"> + um evento </a> <br/>
            <table border="1">



                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Local</th>

                        <th>Data</th>

                         <th>Status</th>

                        <th>Nome do Evento</th>



                    </tr>

                </thead>



                <tbody>

                    {

                        eventos.map(function (eve) {

                            return (

                                <tr key={eve.id}>

                                    <td>{eve.id}</td>

                                    <td>{eve.lugar}</td>

                                    <td>{eve.data}</td>

                                     <td>{eve.status}</td>

                                    <td>{eve.nome_eve}</td>


                                </tr>

                            )

                        })

                    }

                </tbody>



            </table>



        </div>

    );

}



export default TelaEventos;