function Home() {

    return (
  
      <div>
  
        <h1>Bem-vindo a Florentina</h1>
  
        <p>Este é um exemplo de página inicial.</p>
  
      </div>
  
    );
  
  }
  
  
  
  export default Home;