import { DataTypes } from "sequelize";

import mysql from "./mysql.js";



const Modelos = mysql.define('Modelos', {

    nome: DataTypes.STRING,

    pais: DataTypes.STRING

});



const Clientes = mysql.define('Clientes', {

    nome: DataTypes.STRING,

    cnpj: DataTypes.INTEGER

});



const Funcionarios = mysql.define('Funcionarios', {

    nome: DataTypes.STRING,

    descricao: DataTypes.STRING

});

const Eventos = mysql.define('Eventos', {

    lugar: DataTypes.STRING,

    data: DataTypes.DATE,


});

const Contratos = mysql.define('Contratos', {

    datini: DataTypes.DATE,

    datfim: DataTypes.DATE

});


Contratos.belongsTo(Modelos);

Modelos.hasMany(Contratos);


Contratos.belongsTo(Clientes);

Clientes.hasMany(Contratos);


Eventos.belongsTo(Modelos);

Modelos.hasMany(Eventos);


Eventos.belongsTo(Clientes);

Clientes.hasMany(Eventos);



Contratos.belongsToMany(Modelos, { through: 'Modelos_Contratos' });

Modelos.belongsToMany(Contratos, { through: 'Modelos_Contratos' });


Contratos.belongsToMany(Clientes, { through: 'Clientes_Contratos' });

Clientes.belongsToMany(Contratos, { through: 'Clientes_Contratos' });


Eventos.belongsToMany(Modelos, { through: 'Modelos_Eventos' });

Modelos.belongsToMany(Eventos, { through: 'Modelo_Eventos' });


Eventos.belongsToMany(Clientes, { through: 'Clientes_Eventos' });

Clientes.belongsToMany(Eventos, { through: 'Clientes_Eventos' });


mysql.sync();



export { Modelos, Clientes, Eventos, Funcionarios, Contratos, mysql };