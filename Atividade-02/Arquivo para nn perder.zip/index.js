import express from 'express'; 
import {Modelos, Clientes, Eventos, Funcionarios, Contratos} from "./database/tables.js";

const app = express ();

app.use('/modelos', async (req, res) => {

    const modelos = await Modelos.findAll();

    res.json(modelos);

});



app.use('/clientes', async (req, res) => {

    const clientes = await Clientes.findAll();

    res.json(clientes);

});



app.use('/eventos', async (req, res) => {

    const eventos = await Eventos.findAll();

    res.json(eventos);

});

app.use('/contratos', async (req, res) => {

    const contratos = await Contratos.findAll();

    res.json(contratos);

});

app.use('/funcionarios', async (req, res) => {

    const funcionarios = await Funcionarios.findAll();

    res.json(funcionarios);

});

app.use('/cadastros', async (req, res) => {

    const con1 = await Contratos.create({datini: '2009-05-03', datfim: '2025-08-08' });

    const con2 = await Contratos.create({datini: '2025-08-08', datfim: '2026-09-17' });


    const eve1 = await Eventos.create({lugar: 'Rua São Pedro', data: '2002-06-09'});


    const mod1 = await Modelos.create({nome: 'Cínthia Emanuelle', pais: 'Brasil', ContratosId: con1.id, EventosId: eve1.id });

    const mod2 = await Modelos.create({nome: 'Camila Emanuelle', pais: 'Brasil', ContratosId:con2.id, EventosId: eve1.id });

    const mod3 = await Modelos.create({nome: 'Caroline Emanuelle', pais: 'Brasil', EventosId:con3.id, EventosId: eve1.id });



    const fun1 = await Funcionarios.create({nome: 'Lucas Mendes', descricao: 'maquiador'});

    const fun2 = await Funcionarios.create({nome: 'Olívia Louisiana', descricao: 'cabeleleiro' });





    const fi1 = await Filme.create({

        titulo: 'A Barca', 

        descricao: 'Sobre assuntos diverso', 

        ano: 2021,

        DiretorId: dir1.id

    });



    const fi2 = await Filme.create({

        titulo: 'Névoa Densa', 

        descricao: 'Filme feito para encantar', 

        ano: 2021,

        DiretorId: dir2.id

    });



    await fi1.setAtors([at1, at2]);

    await fi2.setAtors([at2, at3]);



    res.end('Tudo cadastrado!');

});



app.listen(80, () => {

    console.log('Escutando...');

});


/*app.use('/', (req, res) =>{
    res.end('Hello Node.js');
});

app.listen(80, () => {
    console.log('Escutando');
});*/